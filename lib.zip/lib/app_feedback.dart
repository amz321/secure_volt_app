import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class FeedbackPage extends StatefulWidget {
  const FeedbackPage({super.key});

  @override
  State<FeedbackPage> createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  List feedbacks = [];
  bool isLoading = false;

  final TextEditingController _feedbackController = TextEditingController();
  double _rating = 0;

  String baseUrl = "";
  String lid = "";

  @override
  void initState() {
    super.initState();
    _loadPref();
  }

  Future<void> _loadPref() async {
    final sp = await SharedPreferences.getInstance();
    setState(() {
      baseUrl = sp.getString("url") ?? "";
      lid = sp.getString("lid") ?? "";
    });

    if (baseUrl.isNotEmpty) {
      fetchFeedbacks();
    }
  }

  Future<void> fetchFeedbacks() async {
    setState(() => isLoading = true);

    try {
      final res = await http.get(Uri.parse("$baseUrl/UserViewFeedbacks/"));
      final jsonData = json.decode(res.body);

      if (jsonData["status"] == "ok") {
        setState(() {
          feedbacks = jsonData["data"] ?? [];
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to load feedbacks")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }

    setState(() => isLoading = false);
  }

  Future<void> sendFeedback() async {
    if (_rating == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please give rating")),
      );
      return;
    }

    if (_feedbackController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please write feedback")),
      );
      return;
    }

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/UserSendFeedback/"),
        body: {
          "lid": lid,
          "rating": _rating.toString(),
          "feedback": _feedbackController.text.trim(),
        },
      );

      final jsonData = json.decode(res.body);

      if (jsonData["status"] == "ok") {
        _feedbackController.clear();
        setState(() => _rating = 0);

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Feedback sent successfully ✅")),
        );

        fetchFeedbacks();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to send feedback ❌")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Feedbacks"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: fetchFeedbacks,
          ),
        ],
      ),
      body: Column(
        children: [
          // SEND FEEDBACK CARD
          Card(
            margin: const EdgeInsets.all(12),
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Give Feedback",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),

                  // STARS
                  RatingBar.builder(
                    initialRating: _rating,
                    minRating: 1,
                    allowHalfRating: true,
                    itemSize: 32,
                    itemPadding: const EdgeInsets.symmetric(horizontal: 3),
                    itemBuilder: (context, _) => const Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (rating) {
                      setState(() => _rating = rating);
                    },
                  ),

                  const SizedBox(height: 10),

                  TextField(
                    controller: _feedbackController,
                    maxLines: 3,
                    decoration: InputDecoration(
                      hintText: "Write your feedback here...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.send),
                      label: const Text("Submit Feedback"),
                      onPressed: sendFeedback,
                    ),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: 5),

          // FEEDBACK LIST
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : feedbacks.isEmpty
                ? const Center(child: Text("No feedbacks yet"))
                : ListView.builder(
              itemCount: feedbacks.length,
              itemBuilder: (context, index) {
                final f = feedbacks[index];

                return Card(
                  margin: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  elevation: 2,
                  child: ListTile(
                    leading: CircleAvatar(
                      radius: 26,
                      backgroundImage: (f["user_photo"] != null &&
                          f["user_photo"].toString().isNotEmpty)
                          ? NetworkImage(f["user_photo"])
                          : null,
                      child: (f["user_photo"] == null ||
                          f["user_photo"].toString().isEmpty)
                          ? const Icon(Icons.person)
                          : null,
                    ),
                    title: Text(
                      f["user"] ?? "User",
                      style: const TextStyle(
                          fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 3),

                        RatingBarIndicator(
                          rating: double.tryParse(
                              f["rating"].toString()) ??
                              0,
                          itemBuilder: (context, index) =>
                          const Icon(Icons.star,
                              color: Colors.amber),
                          itemCount: 5,
                          itemSize: 18,
                        ),

                        const SizedBox(height: 5),
                        Text(f["feedback"] ?? ""),

                        const SizedBox(height: 4),
                        Text(
                          "Date: ${f["date"]}",
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
