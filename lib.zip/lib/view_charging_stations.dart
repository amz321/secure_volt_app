import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class NearestStationsPage extends StatefulWidget {
  const NearestStationsPage({super.key});

  @override
  State<NearestStationsPage> createState() => _NearestStationsPageState();
}

class _NearestStationsPageState extends State<NearestStationsPage> {
  String baseUrl = "";
  bool isLoading = false;

  Position? currentPosition;

  List allStations = [];
  List filteredStations = [];

  String selectedType = "All"; // All / Station / Relay Station

  @override
  void initState() {
    super.initState();
    loadPrefAndFetch();
  }

  Future<void> loadPrefAndFetch() async {
    final sp = await SharedPreferences.getInstance();
    baseUrl = sp.getString("url") ?? "";

    fetchStations();
  }

  Future<void> fetchStations() async {
    setState(() => isLoading = true);

    try {
      final res = await http.get(Uri.parse("$baseUrl/UserViewChargingStations/"));
      final jsonData = json.decode(res.body);

      if (jsonData["status"] == "ok") {
        allStations = jsonData["data"] ?? [];
        applyFilterAndSort();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching stations: $e")),
      );
    }

    setState(() => isLoading = false);
  }

  // ===================== LOCATION =====================
  Future<void> getMyLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please enable location services")),
        );
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Location permission denied")),
          );
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Location permission permanently denied")),
        );
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() => currentPosition = pos);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Location fetched ✅")),
      );

      applyFilterAndSort();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Location error: $e")),
      );
    }
  }

  // ===================== DISTANCE =====================
  double _deg2rad(double deg) => deg * (pi / 180);

  double calculateDistanceKm(double lat1, double lon1, double lat2, double lon2) {
    const double R = 6371; // km
    double dLat = _deg2rad(lat2 - lat1);
    double dLon = _deg2rad(lon2 - lon1);
    double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_deg2rad(lat1)) * cos(_deg2rad(lat2)) * sin(dLon / 2) * sin(dLon / 2);
    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }

  // ===================== FILTER + SORT =====================
  void applyFilterAndSort() {
    List temp = List.from(allStations);

    // filter by type
    if (selectedType != "All") {
      temp = temp.where((s) => (s["type"] ?? "") == selectedType).toList();
    }

    // attach distance if location available
    if (currentPosition != null) {
      for (var s in temp) {
        double lat = double.tryParse(s["latitude"].toString()) ?? 0;
        double lon = double.tryParse(s["longitude"].toString()) ?? 0;

        s["distance"] = calculateDistanceKm(
          currentPosition!.latitude,
          currentPosition!.longitude,
          lat,
          lon,
        );
      }

      // sort nearest
      temp.sort((a, b) =>
          (a["distance"] ?? 999999).compareTo((b["distance"] ?? 999999)));
    }

    setState(() => filteredStations = temp);
  }

  // ===================== OPEN GOOGLE MAPS =====================
  Future<void> openGoogleMaps(double lat, double lon) async {
    // 1) Try open Google Maps App directly
    final Uri gmapUri = Uri.parse("google.navigation:q=$lat,$lon&mode=d");

    if (await canLaunchUrl(gmapUri)) {
      await launchUrl(gmapUri, mode: LaunchMode.externalApplication);
      return;
    }

    // 2) Fallback: open in browser (works always)
    final Uri webUri = Uri.parse(
        "https://www.google.com/maps/search/?api=1&query=$lat,$lon");

    if (await canLaunchUrl(webUri)) {
      await launchUrl(webUri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not open Google Maps")),
      );
    }
  }

  // ===================== UI =====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Nearest Charging Stations"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: fetchStations,
          ),
        ],
      ),
      body: Column(
        children: [
          // TOP CONTROLS
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                // Location button
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: getMyLocation,
                        icon: const Icon(Icons.my_location),
                        label: Text(
                          currentPosition == null
                              ? "Get Current Location"
                              : "Location Set ✅",
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton(
                      onPressed: () {
                        setState(() {
                          selectedType = "All";
                        });
                        applyFilterAndSort();
                      },
                      icon: const Icon(Icons.filter_alt_off),
                      tooltip: "Clear Filter",
                    ),
                  ],
                ),

                const SizedBox(height: 10),

                // Filter by type
                DropdownButtonFormField<String>(
                  value: selectedType,
                  decoration: const InputDecoration(
                    labelText: "Filter by Station Type",
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(value: "All", child: Text("All")),
                    DropdownMenuItem(value: "station", child: Text("Station")),
                    DropdownMenuItem(value: "relay station", child: Text("Relay Station")),
                  ],
                  onChanged: (val) {
                    setState(() => selectedType = val!);
                    applyFilterAndSort();
                  },
                ),
              ],
            ),
          ),

          const Divider(height: 0),

          // LIST
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : filteredStations.isEmpty
                ? const Center(child: Text("No stations found"))
                : ListView.builder(
              itemCount: filteredStations.length,
              itemBuilder: (context, index) {
                final s = filteredStations[index];

                final name = s["name"] ?? "";
                final place = s["place"] ?? "";
                final phone = s["phone"] ?? "";
                final type = s["type"] ?? "";
                final proof = s["proof"] ?? "";

                final lat = double.tryParse(s["latitude"].toString()) ?? 0;
                final lon = double.tryParse(s["longitude"].toString()) ?? 0;

                final dist = s["distance"];

                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Image
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: proof.toString().isNotEmpty
                              ? Image.network(
                            proof,
                            height: 80,
                            width: 80,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                            const Icon(Icons.ev_station, size: 55),
                          )
                              : const Icon(Icons.ev_station, size: 55),
                        ),

                        const SizedBox(width: 10),

                        // Info
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text("Place: $place"),
                              Text("Type: $type"),
                              Text("Phone: $phone"),

                              const SizedBox(height: 6),

                              if (currentPosition != null && dist != null)
                                Text(
                                  "Distance: ${dist.toStringAsFixed(2)} km",
                                  style: const TextStyle(
                                    color: Colors.green,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                            ],
                          ),
                        ),

                        // Locate button
                        IconButton(
                          onPressed: () => openGoogleMaps(lat, lon),
                          icon: const Icon(Icons.location_on),
                          color: Colors.red,
                          tooltip: "Locate on Google Maps",
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
