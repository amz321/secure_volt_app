import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ComplaintPage extends StatefulWidget {
  const ComplaintPage({super.key});

  @override
  State<ComplaintPage> createState() => _ComplaintPageState();
}

class _ComplaintPageState extends State<ComplaintPage> {
  String baseUrl = "";
  String lid = "";

  bool isLoading = false;
  List complaints = [];

  final TextEditingController _complaintController = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadPref();
  }

  Future<void> loadPref() async {
    final sp = await SharedPreferences.getInstance();
    setState(() {
      baseUrl = sp.getString("url") ?? "";
      lid = sp.getString("lid") ?? "";
    });

    fetchComplaints();
  }

  // ================= VIEW COMPLAINTS =================
  Future<void> fetchComplaints() async {
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/ViewComplaintResponse/"),
        body: {"lid": lid},
      );

      final jsonData = json.decode(res.body);

      if (jsonData["status"] == "ok") {
        setState(() {
          complaints = jsonData["data"] ?? [];
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching complaints: $e")),
      );
    }

    setState(() => isLoading = false);
  }

  // ================= SEND COMPLAINT =================
  Future<void> sendComplaint() async {
    final text = _complaintController.text.trim();

    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter complaint")),
      );
      return;
    }

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/UserSendComplaint/"),
        body: {
          "lid": lid,
          "complaint": text,
        },
      );

      final jsonData = json.decode(res.body);

      if (jsonData["status"] == "ok") {
        _complaintController.clear();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Complaint sent ✅")),
        );

        fetchComplaints();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to send complaint ❌")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Report / Complaints"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: fetchComplaints,
          )
        ],
      ),
      body: Column(
        children: [
          // SEND COMPLAINT BOX
          Card(
            margin: const EdgeInsets.all(12),
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Send Complaint",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _complaintController,
                    maxLines: 4,
                    decoration: InputDecoration(
                      hintText: "Write your complaint...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: sendComplaint,
                      icon: const Icon(Icons.send),
                      label: const Text("Submit"),
                    ),
                  )
                ],
              ),
            ),
          ),

          const SizedBox(height: 4),

          // COMPLAINT LIST
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : complaints.isEmpty
                ? const Center(child: Text("No complaints sent yet"))
                : ListView.builder(
              itemCount: complaints.length,
              itemBuilder: (context, index) {
                final c = complaints[index];

                String complaint = c["complaint"] ?? "";
                String reply = c["reply"] ?? "pending";
                String date = c["date"].toString();

                bool isPending =
                reply.toLowerCase().contains("pending");

                return Card(
                  margin: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Complaint
                        Text(
                          "Complaint:",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.grey.shade800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(complaint),

                        const SizedBox(height: 10),

                        // Reply
                        Row(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Reply: ",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.grey.shade800,
                              ),
                            ),
                            Expanded(
                              child: Text(
                                reply,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: isPending
                                      ? Colors.orange
                                      : Colors.green,
                                ),
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 8),

                        // Date
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "Date: $date",
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
