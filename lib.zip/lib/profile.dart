import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class ViewProfile extends StatefulWidget {
  @override
  _ViewProfileState createState() => _ViewProfileState();
}

class _ViewProfileState extends State<ViewProfile> {
  Map<String, dynamic>? profileData;
  String ip = "";
  String lid = "";

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  Future<void> loadPrefs() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ip = prefs.getString('url') ?? "";
    lid = prefs.getString('lid') ?? "";
  }

  Future<void> fetchProfile() async {
    await loadPrefs();

    final response = await http.post(
      Uri.parse("$ip/view_profile_flutter/"),
      body: {"lid": lid},
    );

    if (response.statusCode == 200) {
      setState(() {
        profileData = json.decode(response.body);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Profile"),
        actions: [
          if (profileData != null)
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        UpdateProfile(profileData!),
                  ),
                );
                fetchProfile();
              },
            )
        ],
      ),
      body: profileData == null
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            CircleAvatar(
              radius: 60,
              backgroundImage: NetworkImage(
                "${profileData!['photo']}",
              ),
            ),
            const SizedBox(height: 20),
            profileItem("Name", profileData!['name']),
            profileItem("Email", profileData!['email']),
            profileItem("Phone",
                profileData!['phone'].toString()),
            profileItem("Place", profileData!['place']),
          ],
        ),
      ),
    );
  }

  Widget profileItem(String title, String value) {
    return Card(
      child: ListTile(
        title: Text(title),
        subtitle: Text(value),
      ),
    );
  }
}


class UpdateProfile extends StatefulWidget {
  final Map<String, dynamic> data;
  const UpdateProfile(this.data, {Key? key}) : super(key: key);

  @override
  _UpdateProfileState createState() => _UpdateProfileState();
}

class _UpdateProfileState extends State<UpdateProfile> {
  late TextEditingController name;
  late TextEditingController email;
  late TextEditingController phone;
  late TextEditingController place;

  String ip = "";
  String lid = "";

  XFile? _image;

  @override
  void initState() {
    super.initState();
    name = TextEditingController(text: widget.data['name']);
    email = TextEditingController(text: widget.data['email']);
    phone = TextEditingController(text: widget.data['phone'].toString());
    place = TextEditingController(text: widget.data['place']);
    loadPrefs();
  }

  Future<void> loadPrefs() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    ip = prefs.getString('url') ?? "";
    lid = prefs.getString('lid') ?? "";
    setState(() {});
  }

  /// 📸 Pick from camera
  Future<void> _imgFromCamera() async {
    final image = await ImagePicker().pickImage(
      source: ImageSource.camera,
      imageQuality: 60,
    );
    if (image != null) {
      setState(() {
        _image = image;
      });
    }
  }

  /// 🖼 Pick from gallery
  Future<void> _imgFromGallery() async {
    final image = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: 60,
    );
    if (image != null) {
      setState(() {
        _image = image;
      });
    }
  }

  /// 📂 Bottom sheet
  void _showPicker(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (_) {
        return SafeArea(
          child: Wrap(
            children: [
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text("Gallery"),
                onTap: () {
                  _imgFromGallery();
                  Navigator.pop(context);
                },
              ),
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text("Camera"),
                onTap: () {
                  _imgFromCamera();
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  /// 🚀 Update profile with image
  Future<void> updateProfile() async {
    var request = http.MultipartRequest(
      "POST",
      Uri.parse("$ip/update_profile_flutter/"),
    );

    request.fields['lid'] = lid;
    request.fields['name'] = name.text;
    request.fields['email'] = email.text;
    request.fields['phone'] = phone.text;
    request.fields['place'] = place.text;

    if (_image != null) {
      request.files.add(
        await http.MultipartFile.fromPath(
          'photo',
          _image!.path,
        ),
      );
    }

    var response = await request.send();

    if (response.statusCode == 200) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Update Profile")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            /// 👤 PROFILE IMAGE
            GestureDetector(
              onTap: () => _showPicker(context),
              child:CircleAvatar(
                radius: 55,
                backgroundColor: Colors.grey[300],
                backgroundImage: _image != null
                    ? FileImage(File(_image!.path))
                    : (widget.data['photo'] != null
                    ? NetworkImage("${widget.data['photo']}") as ImageProvider
                    : null),
                child: (_image == null && widget.data['photo'] == null)
                    ? const Icon(Icons.camera_alt, size: 30)
                    : null,
              ),

            ),

            const SizedBox(height: 25),

            TextField(
              controller: name,
              decoration: const InputDecoration(labelText: "Name"),
            ),
            TextField(
              controller: email,
              decoration: const InputDecoration(labelText: "Email"),
            ),
            TextField(
              controller: phone,
              decoration: const InputDecoration(labelText: "Phone"),
              keyboardType: TextInputType.phone,
            ),
            TextField(
              controller: place,
              decoration: const InputDecoration(labelText: "Place"),
            ),

            const SizedBox(height: 25),

            ElevatedButton(
              onPressed: updateProfile,
              child: const Text("Update Profile"),
            ),
          ],
        ),
      ),
    );
  }
}

