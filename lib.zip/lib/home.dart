import 'package:flutter/material.dart';
import 'package:secure_volt/profile.dart';
import 'package:secure_volt/view_charging_stations.dart';
import 'package:secure_volt/view_parking.dart';

import 'app_complaints.dart';
import 'app_feedback.dart';
import 'change_password.dart';
import 'login.dart';
import 'manage_my_ev.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Secure Volt"),
      ),
      body: Column(
        children:  [
          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ViewProfile()));
          }, child: Text('profile')),

          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>FeedbackPage()));
          }, child: Text('App ratings')),

          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ChangePassword()));
          }, child: Text('Change Password')),

          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ManageVehiclePage()));
          }, child: Text('Manage My EV Vehicles')),

          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>NearestStationsPage()));
          }, child: Text('Charging Stations near me'))
          ,
          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ParkingNearMePage()));
          }, child: Text('Parking Area near me')),

          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>ComplaintPage()));
          }, child: Text('App Reports')),



          ElevatedButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>login()));
          }, child: Text('Logout')),
        ],
      )
    );
  }
}
