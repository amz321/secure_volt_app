import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ManageVehiclePage extends StatefulWidget {
  const ManageVehiclePage({super.key});

  @override
  State<ManageVehiclePage> createState() => _ManageVehiclePageState();
}

class _ManageVehiclePageState extends State<ManageVehiclePage> {
  List vehicles = [];
  bool isLoading = false;

  String baseUrl = "";
  String lid = "";

  @override
  void initState() {
    super.initState();
    loadPref();
  }

  Future<void> loadPref() async {
    final sp = await SharedPreferences.getInstance();
    setState(() {
      baseUrl = sp.getString("url") ?? "";
      lid = sp.getString("lid") ?? "";
    });

    fetchVehicles();
  }

  Future<void> fetchVehicles() async {
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/UserViewOwnVehicles/"),
        body: {"lid": lid},
      );

      final jsonData = json.decode(res.body);
      if (jsonData["status"] == "ok") {
        setState(() {
          vehicles = jsonData["data"] ?? [];
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error loading vehicles: $e")),
      );
    }

    setState(() => isLoading = false);
  }

  Future<void> deleteVehicle(String vid) async {
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/RemoveVehicle/"),
        body: {"vid": vid},
      );

      final jsonData = json.decode(res.body);
      if (jsonData["status"] == "ok") {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Vehicle removed ✅")),
        );
        fetchVehicles();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error deleting: $e")),
      );
    }
  }

  // ========================== BottomSheet Add/Edit ==========================
  void openVehicleBottomSheet({Map? vehicle}) {
    final bool isEdit = vehicle != null;

    final nameController =
    TextEditingController(text: isEdit ? vehicle["vehicle_name"] : "");
    final noController =
    TextEditingController(text: isEdit ? vehicle["vehicle_no"] : "");

    String vehicleType = isEdit ? vehicle["vehicle_type"] : "Two Wheeler";

    File? imageFile;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            Future<void> pickImage() async {
              final picked = await ImagePicker().pickImage(
                source: ImageSource.gallery,
                imageQuality: 80,
              );
              if (picked != null) {
                setModalState(() {
                  imageFile = File(picked.path);
                });
              }
            }

            return Padding(
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 16,
                bottom: MediaQuery.of(context).viewInsets.bottom + 20,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      height: 5,
                      width: 60,
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade400,
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    Text(
                      isEdit ? "Edit Vehicle" : "Add Vehicle",
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),

                    TextField(
                      controller: nameController,
                      decoration: const InputDecoration(
                        labelText: "Vehicle Name",
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 12),

                    TextField(
                      controller: noController,
                      decoration: const InputDecoration(
                        labelText: "Vehicle Number",
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 12),

                    DropdownButtonFormField<String>(
                      value: vehicleType,
                      items: const [
                        DropdownMenuItem(
                            value: "Two Wheeler", child: Text("Two Wheeler")),
                        DropdownMenuItem(
                            value: "Four Wheeler", child: Text("Four Wheeler")),
                      ],
                      onChanged: (val) {
                        setModalState(() => vehicleType = val!);
                      },
                      decoration: const InputDecoration(
                        labelText: "Vehicle Type",
                        border: OutlineInputBorder(),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Image pick
                    Row(
                      children: [
                        ElevatedButton.icon(
                          onPressed: pickImage,
                          icon: const Icon(Icons.image),
                          label: const Text("Pick Photo"),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            imageFile != null
                                ? "Selected ✅"
                                : (isEdit
                                ? "Optional (keep old photo)"
                                : "No image"),
                            style: const TextStyle(fontSize: 13),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 18),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        icon: Icon(isEdit ? Icons.update : Icons.add),
                        label: Text(isEdit ? "Update" : "Add"),
                        onPressed: () async {
                          if (nameController.text.trim().isEmpty ||
                              noController.text.trim().isEmpty) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text("Fill all fields")),
                            );
                            return;
                          }

                          if (!isEdit && imageFile == null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                  content: Text("Please select vehicle photo")),
                            );
                            return;
                          }

                          Navigator.pop(context);

                          if (isEdit) {
                            await updateVehicle(
                              vid: vehicle["id"].toString(),
                              vehicleName: nameController.text.trim(),
                              vehicleNo: noController.text.trim(),
                              vehicleType: vehicleType,
                              imageFile: imageFile,
                            );
                          } else {
                            await addVehicle(
                              vehicleName: nameController.text.trim(),
                              vehicleNo: noController.text.trim(),
                              vehicleType: vehicleType,
                              imageFile: imageFile!,
                            );
                          }
                        },
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ========================== API ADD VEHICLE ==========================
  Future<void> addVehicle({
    required String vehicleName,
    required String vehicleNo,
    required String vehicleType,
    required File imageFile,
  }) async {
    try {
      final uri = Uri.parse("$baseUrl/UserAddVehicle/");
      var req = http.MultipartRequest("POST", uri);

      req.fields["lid"] = lid;
      req.fields["vehicle_name"] = vehicleName;
      req.fields["vehicle_no"] = vehicleNo;
      req.fields["vehicle_type"] = vehicleType;

      req.files.add(await http.MultipartFile.fromPath("photo", imageFile.path));

      final streamed = await req.send();
      final response = await http.Response.fromStream(streamed);
      final jsonData = json.decode(response.body);

      if (jsonData["status"] == "ok") {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Vehicle added ✅")),
        );
        fetchVehicles();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to add ❌")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  // ========================== API UPDATE VEHICLE ==========================
  Future<void> updateVehicle({
    required String vid,
    required String vehicleName,
    required String vehicleNo,
    required String vehicleType,
    File? imageFile,
  }) async {
    try {
      final uri = Uri.parse("$baseUrl/UpdateVehicle/");
      var req = http.MultipartRequest("POST", uri);

      req.fields["vid"] = vid;
      req.fields["vehicle_name"] = vehicleName;
      req.fields["vehicle_no"] = vehicleNo;
      req.fields["vehicle_type"] = vehicleType;

      if (imageFile != null) {
        req.files
            .add(await http.MultipartFile.fromPath("photo", imageFile.path));
      }

      final streamed = await req.send();
      final response = await http.Response.fromStream(streamed);
      final jsonData = json.decode(response.body);

      if (jsonData["status"] == "ok") {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Vehicle updated ✅")),
        );
        fetchVehicles();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Failed to update ❌")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  // ========================== UI ==========================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Vehicles"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: fetchVehicles,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => openVehicleBottomSheet(),
        child: const Icon(Icons.add),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : vehicles.isEmpty
          ? const Center(child: Text("No vehicles added"))
          : ListView.builder(
        itemCount: vehicles.length,
        itemBuilder: (context, index) {
          final v = vehicles[index];

          return Card(
            margin: const EdgeInsets.symmetric(
                horizontal: 12, vertical: 6),
            child: ListTile(
              leading: CircleAvatar(
                radius: 26,
                backgroundImage: (v["photo"] != null &&
                    v["photo"].toString().isNotEmpty)
                    ? NetworkImage(v["photo"])
                    : null,
                child: (v["photo"] == null ||
                    v["photo"].toString().isEmpty)
                    ? const Icon(Icons.directions_car)
                    : null,
              ),
              title: Text(
                v["vehicle_name"] ?? "",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                "${v["vehicle_no"]}\n${v["vehicle_type"]}",
              ),
              isThreeLine: true,
              trailing: PopupMenuButton(
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: "edit",
                    child: Text("Edit"),
                  ),
                  const PopupMenuItem(
                    value: "delete",
                    child: Text("Delete"),
                  ),
                ],
                onSelected: (value) {
                  if (value == "edit") {
                    openVehicleBottomSheet(vehicle: v);
                  } else if (value == "delete") {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text("Confirm Delete"),
                        content: const Text(
                            "Are you sure to delete this vehicle?"),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text("Cancel"),
                          ),
                          ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                              deleteVehicle(v["id"].toString());
                            },
                            child: const Text("Delete"),
                          ),
                        ],
                      ),
                    );
                  }
                },
              ),
            ),
          );
        },
      ),
    );
  }
}
