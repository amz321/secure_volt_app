import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class ParkingNearMePage extends StatefulWidget {
  const ParkingNearMePage({super.key});

  @override
  State<ParkingNearMePage> createState() => _ParkingNearMePageState();
}

class _ParkingNearMePageState extends State<ParkingNearMePage> {
  String baseUrl = "";

  bool isLoading = false;
  Position? currentPosition;

  List allParkings = [];
  List filteredParkings = [];

  String selectedPlace = "All"; // filter place dropdown

  @override
  void initState() {
    super.initState();
    loadPref();
  }

  Future<void> loadPref() async {
    final sp = await SharedPreferences.getInstance();
    baseUrl = sp.getString("url") ?? "";
    fetchParkings();
  }

  // ===================== FETCH PARKINGS =====================
  Future<void> fetchParkings() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse("$baseUrl/UserViewParkings/"));
      final jsonData = json.decode(res.body);

      if (jsonData["status"] == "ok") {
        allParkings = jsonData["data"] ?? [];
        applyFilterAndSort();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching parkings: $e")),
      );
    }

    setState(() => isLoading = false);
  }

  // ===================== LOCATION =====================
  Future<void> getMyLocation() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please enable location service")),
        );
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Location permission denied")),
        );
        return;
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      setState(() => currentPosition = pos);
      applyFilterAndSort();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Location fetched ✅")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Location error: $e")),
      );
    }
  }

  // ===================== DISTANCE =====================
  double _deg2rad(double deg) => deg * (pi / 180);

  double calculateDistanceKm(double lat1, double lon1, double lat2, double lon2) {
    const double R = 6371;
    double dLat = _deg2rad(lat2 - lat1);
    double dLon = _deg2rad(lon2 - lon1);

    double a = sin(dLat / 2) * sin(dLat / 2) +
        cos(_deg2rad(lat1)) *
            cos(_deg2rad(lat2)) *
            sin(dLon / 2) *
            sin(dLon / 2);

    double c = 2 * atan2(sqrt(a), sqrt(1 - a));
    return R * c;
  }

  // ===================== FILTER + SORT =====================
  void applyFilterAndSort() {
    List temp = List.from(allParkings);

    // filter place
    if (selectedPlace != "All") {
      temp = temp.where((p) => (p["place"] ?? "") == selectedPlace).toList();
    }

    // attach distance + sort nearest
    if (currentPosition != null) {
      for (var p in temp) {
        double lat = double.tryParse(p["latitude"].toString()) ?? 0;
        double lon = double.tryParse(p["longitude"].toString()) ?? 0;

        p["distance"] = calculateDistanceKm(
          currentPosition!.latitude,
          currentPosition!.longitude,
          lat,
          lon,
        );
      }

      temp.sort((a, b) =>
          (a["distance"] ?? 999999).compareTo((b["distance"] ?? 999999)));
    }

    setState(() => filteredParkings = temp);
  }

  // ===================== GOOGLE MAPS =====================
  Future<void> openGoogleMaps(double lat, double lon) async {
    final Uri gmapUri = Uri.parse("google.navigation:q=$lat,$lon&mode=d");

    if (await canLaunchUrl(gmapUri)) {
      await launchUrl(gmapUri, mode: LaunchMode.externalApplication);
      return;
    }

    final Uri webUri =
    Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lon");

    if (await canLaunchUrl(webUri)) {
      await launchUrl(webUri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not open Google Maps")),
      );
    }
  }

  List<String> getPlaces() {
    final places = allParkings
        .map((p) => p["place"].toString())
        .toSet()
        .toList();
    places.sort();
    return ["All", ...places];
  }

  // ===================== UI =====================
  @override
  Widget build(BuildContext context) {
    final places = getPlaces();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Parking Near Me"),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: fetchParkings,
          ),
        ],
      ),
      body: Column(
        children: [
          // TOP FILTERS
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: getMyLocation,
                        icon: const Icon(Icons.my_location),
                        label: Text(currentPosition == null
                            ? "Get Location"
                            : "Location Set ✅"),
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 10),

                DropdownButtonFormField<String>(
                  value: selectedPlace,
                  items: places
                      .map((pl) => DropdownMenuItem(
                    value: pl,
                    child: Text(pl),
                  ))
                      .toList(),
                  onChanged: (val) {
                    setState(() => selectedPlace = val!);
                    applyFilterAndSort();
                  },
                  decoration: const InputDecoration(
                    labelText: "Filter by Place",
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),

          const Divider(height: 0),

          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : filteredParkings.isEmpty
                ? const Center(child: Text("No parking areas found"))
                : ListView.builder(
              itemCount: filteredParkings.length,
              itemBuilder: (context, index) {
                final p = filteredParkings[index];

                final name = p["name"] ?? "";
                final place = p["place"] ?? "";
                final phone = p["phone"] ?? "";
                final proof = p["proof"] ?? "";

                final lat =
                    double.tryParse(p["latitude"].toString()) ?? 0;
                final lon =
                    double.tryParse(p["longitude"].toString()) ?? 0;

                final dist = p["distance"];

                return Card(
                  margin: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: proof.toString().isNotEmpty
                                  ? Image.network(
                                proof,
                                height: 80,
                                width: 80,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) =>
                                const Icon(
                                    Icons.local_parking,
                                    size: 55),
                              )
                                  : const Icon(Icons.local_parking,
                                  size: 55),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    name,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text("Place: $place"),
                                  Text("Phone: $phone"),
                                  if (currentPosition != null &&
                                      dist != null)
                                    Text(
                                      "Distance: ${dist.toStringAsFixed(2)} km",
                                      style: const TextStyle(
                                        color: Colors.green,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            IconButton(
                              onPressed: () => openGoogleMaps(lat, lon),
                              icon: const Icon(Icons.location_on),
                              color: Colors.red,
                            )
                          ],
                        ),

                        const SizedBox(height: 12),

                        // SLOT BUTTON
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.event_available),
                            label: const Text("Slots"),
                            onPressed: () {
                              // for now only button
                              // later you can navigate to slot page
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text("Open slots for: $name"),
                                ),
                              );

                              // Example navigation later:
                              // Navigator.push(context, MaterialPageRoute(
                              //   builder: (_) => ParkingSlotsPage(parking: p),
                              // ));
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
